# Hướng dẫn kích hoạt App, Game

<div class="my-3">
- Vui lòng xem kỹ dòng màu đỏ để lấy tài khoản kích hoạt cho đúng.

- Truy cập [https://id.codevn.net](#) để lấy tài khoản kích hoạt.

###### Lưu ý:

- Nghiêm cấm tuyệt đối việc đăng nhập tài khoản trên vào iCloud, chúng tôi sẽ không chịu trách nhiệm nếu bạn đăng nhập vào iCloud.

- Mật khẩu có ký tự in hoa và ký tự đặc biệt.

- Nghiêm cấm tuyệt đối việc share công khai tài khoản ra ngoài group iOS CodeVN.

Sau khi đăng nhập mà bạn vẫn bị thoát ra khỏi app thì hãy đăng nhập tài khoản trên vào appstore, tải 1 app free bất kỳ trong mục đã mua sau đó tải lại app tại iOS CodeVN.

</div>