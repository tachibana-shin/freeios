**Bước 1**: Sử dụng trình duyệt <span style="text-decoration: underline;">**Safari**</span> hoặc <span style="text-decoration: underline;">**Puffin**</span> để truy cập vào [https://%WEB](https://%WEB)  

**Bước 2**: Tìm app thích hợp.  
Nếu bạn không thấy app ở trang chủ, bạn có thể sử dụng khung tìm kiếm với từ khóa là tên của app.  

**Bước 3**: Chọn phiên bản và cài đặt.  
Sau khi đã tìm được app bạn đang cần cài đặt, hãy chú ý đến mục **CHỌN PHIÊN BẢN** ngay bên dưới để cài đặt, lúc này sẽ hiện lên 1 thông báo rằng bạn có muốn cài đặt app hay không?  
Chọn **Install** để tiến hành cài đặt.  
Bây giờ bạn chỉ cần ngồi chờ cho đến khi cài đặt xong.  

**Bước 4**: Đăng nhập tài khoản iTunes của iOS CodeVN.  
Sau khi cài đặt xong, hãy mở app đó lên và sử dụng tài khoản mình cung cấp trong group iOS CodeVN để đăng nhập vào app (chỉ cần đăng nhập 1 lần đầu tiên). Bước này rất quan trọng vì nếu không đăng nhập bạn sẽ không dùng được app.  

<span>➡</span> Các app trên iOS CodeVN đều ghi rõ tài khoản kích hoạt app nằm ngay dòng màu đỏ.  
<span>➡</span> Các app không ghi rõ tài khoản kích hoạt đều sử dụng tài khoản ios@codevn.net để kích hoạt.  

**Vui lòng truy cập [%WEB/id](https://%WEB/id) để lấy tài khoản kích hoạt app.**  

<span style="font-size: 18pt;">_**Sau khi đăng nhập mà bạn vẫn bị văng ra khỏi app thì hãy đăng nhập tài khoản vào appstore, tải 1 app free bất kỳ trong mục ĐÃ MUA sau đó tải lại app tại iOS CodeVN.**_</span>  

Chúc các bạn thành công