# Nội quy iOS Free iOS
<div class="text-center">
    <img class="img-fluid" src="https://%WEB/AppIcon.png" style="max-width: 5rem">
	
</div>

<div class="entry-content">

**iOS CodeVN** là Cộng đồng **app iOS phiên bản cũ**. Vui lòng đọc kỹ các điều khoản sau và trả lời đầy đủ các câu hỏi để được xét duyệt tham gia vào group.

1\. Tài khoản kích hoạt app nằm tại website **[https://id.codevn.net](https://id.codevn.net/)**.  
2\. Xin tài khoản trong group -> chưa đọc nội quy -> kick ra khỏi nhóm.  
3\. Nghiêm cấm tuyệt tối việc share các bài live stream bán hàng, hát hò vào group -> block vĩnh viễn.  
4\. Nghiêm cấm buôn bán khi chưa được sự đồng ý của ADMIN -> vi phạm kick ra khỏi nhóm.  
5\. Nghiêm cấm share tài khoản của group ra ngoài -> phát hiện block vĩnh viễn.  
6\. Tài khoản bị khóa, bị change pass vui lòng comment tại bài ghim và tag mình vào -> đăng bài mới về vấn đề này block thẳng tay.  
7\. App đã có trên web còn vô group xin -> kích ra khỏi group vì nút tìm kiếm trên web không phải để cho vui.  
Lần 2 tái phạm -> Block.

–> Vui lòng đọc kỹ FAQs **[tại đây](https://ios.codevn.net/faqs/)** để nắm rõ một số câu hỏi thường gặp.

Nội quy sẽ được cập nhật liên tục để đảm bảo sân chơi lành mạnh, chính vì vậy vui lòng tuân thủ nội quy của group.

</div>