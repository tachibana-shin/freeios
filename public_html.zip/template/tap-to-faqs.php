<div class="alert alert-info text-center font-15px py-15px">
   &gt;&gt;&gt; Bấm vào đây để đọc FAQs &lt;&lt;&lt;
</div>
