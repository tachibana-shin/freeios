<?php
   function renderBreadCrumb($items) {
       $html = '<ol class="breadcrumb">';
       foreach ( $items as $value ) {
           $html .= '
              <li class="breadcrumb-item">
              '.$value.'
              </li>
           ';
       };
       $html .= "</ol>";
   }
?>