<?php
   include "init_mysql.php";
   
   if ( isset($_POST["submit"]) ) {
	   addApp( (object) array(
	      "name" => $_POST["name"],
	      "icon" => $_FILES["icon"],
	      "author" => $_POST["author"],
	      "account" => $_POST["account"],
	      "description" => $_POST["description"],
	      "versions" => $_POST["versions"],
          "replace" => true,
          "category" => $_POST["category"],
          "supports" => $_POST["supports"]
      ));
   };
?>

<form method="post" action="add_app.php"enctype="multipart/form-data">
   <input name="name" value="Test">
   <input name="icon" type="file">
   <input name="author" value="Apple">
   <input name="account" value="Apple">
   <input name="description" value="Apple">
   <input name="versions" value="Apple">
   <input name="category" value="Applie">
   <select name="supports[]" multiple>
      <option selected value="10">
      </option>
      <option selected value="11">
      </option>
   </select>
   <button type"submit" name="submit"> Add </button>
</form>