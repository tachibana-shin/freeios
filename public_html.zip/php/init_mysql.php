<?php
   $sql = new mysqli("localhost", "id10691420_root", "Thanhbanh1995@", "id10691420_my_app") or die("Connect to database failed");
   /*
   if ( !($sql -> select_db("iOS")) ) {
      $sql -> query("CREATE DATABASE iOS");
      $sql -> select_db("iOS");
   };
*/
   
   $sql -> query("CREATE TABLE IF NOT EXISTS Apps (
      name TINYTEXT NOT NULL,
      author TINYTEXT NOT NULL,
      account TINYTEXT,
      description TEXT,
      versions TEXT NOT NULL,
      downloads INT NOT NULL DEFAULT 0,
      views INT NOT NULL DEFAULT 0,
      timeupload TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      category TINYTEXT NOT NULL,
      supports TINYTEXT NOT NULL)");
   echo $sql -> error;
   
   function checkAppExistsDB( $name ) {
      global $sql;
      return $sql -> query("select * from Apps where name='$name'") -> num_rows > 0;
   }
   
   function uploadImage( $img, $name ) {
      $name = urlencode($name);
      
      if ( !is_dir("../upload") ) {
         mkdir("../upload");
      };
      if ( file_exists("upload/$name.png") )
         unlink("../upload/$name.png");
      move_uploaded_file($img["tmp_name"], "../upload/$name.png");
      
   }
   
   function addApp( $info ) {
      global $sql;
      if ( !checkAppExistsDB($info -> name) ) {
         if ( $sql -> query("insert into Apps (
            name, author, account, description, versions, category, supports
            ) values (
            '".addslashes($info -> name)."',
            '".addslashes($info -> author)."', '".addslashes($info -> account)."',
            '".addslashes($info -> description)."',
            '".serialize($info -> versions)."',
            '".addslashes($info -> category)."',
            '".serialize($info -> supports)."'
            )")) {
            uploadImage($info -> icon, $info -> name);
         }
         echo $sql -> error;
      } else if ( $info -> replace ) {
         //updateApp($sql);
      } else {
         die("'$info -> name' exists in database");
      };
         
   };
   function removeApp( $name ) {
      global $sql;
      if ( $sql -> query("delete from Apps where name='$name'") ) {
         unlink("../upload/".urlencode($name).".png");
      };
   };
   
?>