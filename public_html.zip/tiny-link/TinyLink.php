<?php
   include_once "../php/init_mysql.php";
   class TinyLink {
      public function __construct() {
         
         $this -> init("localhost", "id10691420_root", "Thanhbanh1995@", "id10691420_my_app");
         
      }
      private $sql;
      private function init($host, $username, $password, $db = "") {
         global $sql;
         
         if ( isset($sql) ) {
             $this -> sql = $sql;
             
         } else {
         $this -> sql = new mysqli($host, "$username", "$password", $db);
      
         if ( !($this -> sql -> select_db("iOS")) ) {
            $this -> sql -> query("CREATE DATABASE iOS");
            $this -> sql -> select_db("iOS");
         };
         };
         if ( !($this -> sql -> query("select * from TinyLink")) ) {
            $this -> sql -> query("CREATE TABLE TinyLink (
               hash TINYTEXT NOT NULL,
               link TEXT NOT NULL
            )");
            echo $this -> sql -> error;
         };
      }
      
      private function findHashInDB( $url ) {

         $result = $this -> sql -> query("select hash from TinyLink where link = '$url'");
         if ( $result -> num_rows > 0 ) {
            $app = $result -> fetch_array();
		    $result -> free_result();
		    return $app["hash"];
         }
         else return false;
	  }
	  
	  public function createHash( $url ) {
         if ( ($pam = $this -> findHashInDB( trim($url) )) == false ) {
            $pam = substr( str_replace("=", "_", base64_encode( md5( $url.time().rand(0, 9999) ) ) ), 0, 6);
		    if ( !($this -> sql -> query("insert into TinyLink (hash, link) values ('$pam', '$url')")) ) {
               echo $sql -> error;
            } else {
               return $pam;
            };
       	 } else {
	  	    return $pam;
	     };
	  }
	  public function findLink( $pam ) {
	     $result = $this -> sql -> query("select link from TinyLink where hash = '$pam'");
	     if ( $result -> num_rows > 0 ) {
	        $app = $result -> fetch_array();
	        $result -> free_result();
	        return $app["link"];
	     }
	     else return false;
	  }
   }
   
?>
