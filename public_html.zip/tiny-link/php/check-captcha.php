<div class="container bg-light text-center py-3">
   <div class="row">
      <div class="col-12">
         <span class="text-uppercase text-secondary">
            Vui lòng thực hiện yêu cầu xác thực bên dưới để chuyển sang trang đích.
         </span>
		  <br>
         <form method="post">
      			<div class="g-recaptcha" data-sitekey="<?php echo $siteKey;?>"></div>
      			<script type="text/javascript" src="https://www.google.com/recaptcha/api.js?hl=<?php echo $lang;?>"></script><br/>
				<button type="submit" class="mt-3 btn btn-primary"> Bấm vào đây để tiếp tục </button>
         </form>
      </div>
   </div>
</div>
<style>
.text-color-main {
    color: var(--primary) !important
}

.countdown {
    width: 7rem;
    height: 7rem;
    text-align: center;
    vertical-align: middle;
    position: relative;
    border: 2px solid rgba(0, 0, 0, .5) !important
}

.countdown > span {
    position: absolute;
    display: inline-block;
    top: 50%;
    left: 50%;
    
    transform: translate(-50%, -50%);
	font-size: 1.5rem;
	line-height: 1;
	color: rgba(0, 0, 0, .8);
	font-weight: 100;
}
</style>
<script>
function countdown(second) {
    document.getElementsByClassName("seconds")[0].innerHTML = second + "<br>Giây"
	if ( second == 0 ) {
	    let el = document.getElementsByClassName("submit")[0]
		el.disabled = false
		el.textContent = "Lấy liên kết"
       el.addEventListener("click", function() {
          alert("<?php
             echo $_SESSION["link"];
          ?>")
       })
	    return
	}
    setTimeout(function() {
        countdown(--second)
    }, 1000)
}

countdown(15)
</script>