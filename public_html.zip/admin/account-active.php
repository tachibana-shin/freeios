<?
  include "../php/init_mysql.php";
  
  
  if ( ! ($sql -> query("select * from AccountActive")) ) {

     $sql -> query("create table AccountActive (

           id tinytext not null,
           password tinytext not null,
           hide tinyint(1) default 0
         )");
     echo $sql -> error;
  };
  
  if ( isset($_POST["submit"]) ) {
  	 $sql -> query("truncate AccountActive");
     if (
     	isset($_POST["ids"]) &&
     	is_array($_POST["ids"]) &&
     	isset($_POST["pass"]) &&
     	is_array($_POST["pass"])
     )
	 foreach ( $_POST["ids"] as $index => $value ) {
		if ( !isset($_POST["pass"][$index]) )
			continue;
		$sql -> query("insert into AccountActive (id, password) values ('$value', '".$_POST["pass"][$index]."')");
	 }
	 $updated = true;
  };
       
  // exists Table  AccountActive
       
  $result = $sql -> query("select id, password from AccountActive where hide = 0");
  echo $sql -> error;
  
  $ID_ACTIVE = [];
  
  if ( $result -> num_rows > 0 ) {
      while ( $row = $result -> fetch_array())
         array_push($ID_ACTIVE, $row);
  }
  
  $result -> free_result();

  //$sql -> query("insert into AccountActive ( id, password ) values ( 'icloud.com', 'my' )");
  //echo $sql -> error;
 // print_r($ID_ACTIVE);
?>






<!doctype html>

<html>

   <head>
   
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css">
      <!--link rel="stylesheet" href="https://nguyenthanh1995.github.io/lib/bootstrap.min.css">-->
      <link rel="stylesheet" href="https://nguyenthanh1995.github.io/lib/awesome pro/css/all.min.css">
	  <link rel="stylesheet" href="/style.css">
      <script src="https://nguyenthanh1995.github.io/my-new.js"></script>
      <meta name="viewport" content="width=device-width, initial-scale=1.0" charset="utf-8">
      <script src="https://nguyenthanh1995.github.io/my-new.js"></script>
   </head>
   <body>

      <div class="main" id="app">
      
         <div class="container">
            
            <!-- flex apps -->
            <div class="row">
               <div class="col-12 col-lg-8 pt-30px">                   
                  <div class="p-15px bg-white px-3 listWidget">
<?php
	if ( isset($updated) ) {
		echo '
					 <div class="alert alert-'.(!$sql -> error ? "success" : "danger").'">'.
						 (!$sql -> error ? "Cập nhật thành công" : $sql -> error).
					 '</div>';
	};
?>
                     <form method="post" class="m-0 p-0 my-2">
						 
						 <?php
		
		if ( !isset($ID_ACTIVE) || count($ID_ACTIVE) == 0 )
		   echo "<p class='text-secondary'> Không tìm thấy gì trong DB. </p><table></table>";
		else {
		    echo "<table>";
		    foreach ( $ID_ACTIVE as $index => $value ) {
		        echo "<tr>";
		           echo "<td><input name='ids[$index]' class='no-input' value='".$value["id"]."'></td>";
		           echo "<td><input name='pass[$index]' class='no-input' value='".$value["password"]."'></td>";
		           echo "<td class='remove'> Delete </td>";
		        echo "</tr>";
		    }
		    
		    echo "</table>";
		    
		}?>		 
		             
		             <div class="d-flex justify-content-between mt-3">

                     	 <a class='btn btn-outline-dark addRows'> Thêm </a>
						 <button class="btn btn-outline-primary" name="submit" type="submit"> Cập nhật </button>

					 </div>
					 
					 <div class="d-none mt-3">
						<label> Bị xóa khỏi DB </label>
						<table class="deleted"></table>
					 </div>
		             
                     </form>
                     
                     <div class="text-secondary small">
						Tap to text editable!
					 </div>
                  </div>
               </div>
               
               <!-- -->
               
               
               <!-- -->
               
            </div>
            
            <!-- -->
           
         </div>
         
      </div>
      
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js"></script>
      
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
      
      <script>
          my(".remove").each((index, item) => {
              my(item).click(() => {
                  let TR_DELETE = my(item).closest("tr")

				  TR_DELETE.find("input")
				  .each((index, item) => {
					   my(item).unAttr("name")
				  })
				  
				  TR_DELETE.find(".remove").remove()
				  TR_DELETE.append(`<td class="restore">Khôi phục</td>`)
				  
				  my(".deleted").append(TR_DELETE).removeClass("d-none")
/*
				  if ( my(".deleted").child().length > 0 )
					my(".deleted").removeClass("d-none")
				  else
				  	my(".deleted").addClass("d-none")*/
              })
          })
          
          onerror = e => alert(e + "");
          
          my(".addRows").click(() => {
             my("table").append(`
                <tr>
                   <td> <input name="ids[]" class='no-input' required placeholder="Tên đăng nhập"> </td>
				   <td> <input name="pass[]" class='no-input' required placeholder="Mật khẩu"> </td>
				   <td class='remove'> Delete </td>
                </tr>
             `)
          })
          
      </script>

	<style>
	table {
		margin: 0 auto;
	}
	
	tr {
		border-top: 1px solid #ccc;
		background-color: #fff;
	}
	
	th {
		text-align: inherit;
		border: 1px solid #ddd;
		padding: 6px 13px;
	}
	
	td {
		border: 1px solid #ddd;
		padding: 6px 13px;
	}
	
.no-input {
    -webkit-appearance: none;
    display: inline-block;
    width: 100%;
    border: 0;
} 
	</style>
   </body>
</html>